package ajs.printutils;

public enum Color {
    RED, GREEN, YELLOW, BLUE, PINK, LIGHT_BLUE, GRAY, GREY, NONE
}
