package ajs.printutils;

public enum Orientation {
    VERTICAL, HORIZONTAL
}